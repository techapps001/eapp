<small class="text-danger">{{  __('Please avoid to use enter key for new line. You can use <br> for new Line')  }}</small>
