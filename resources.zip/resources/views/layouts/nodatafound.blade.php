<tr>
    <td colspan="10" class="text-center">
        <div class="text-center">
            <i class="fas fa-folder-open text-primary fs-40"></i>
            <h2>{{ __('Opps...') }}</h2>
            <h6> {!! __('No Data Found') !!} </h6>
        </div>
    </td>
</tr>
