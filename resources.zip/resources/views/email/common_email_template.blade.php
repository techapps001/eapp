@extends('email.common')
@section('content')
    {!! $content !!}
     
@endsection
